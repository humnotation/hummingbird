// Handler.js
// get the handler function for an XML node based on its name & lineage
//

MXVF.Handler = {};

MXVF.Handler.getHandler = function() {

  // like it would take 'print' and give you back the function MXVF.Handler.Print 

}

MXVF.Handler.Print = function($xmlNode) {

  // perhaps check the lineage if necessary
  // that could be easy from the jQuery selector field
  // handle the attributes of <print>
  // handle the innards and text values as necessary, or allow all that to be delegated normally.

}



